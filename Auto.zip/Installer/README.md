**How to Use**
Open The Installer
Press Install
Select A Font Of Your Choice Or Upload Your Own
Press Finish

If It Freezes At Anytime DO NOT Close It.